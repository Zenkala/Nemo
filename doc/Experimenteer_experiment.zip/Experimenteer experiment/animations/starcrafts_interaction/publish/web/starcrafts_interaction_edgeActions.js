
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){sym.positionZergling=function(newPos){console.log("new position is "+newPos);var symbol=sym.getSymbol("zerglingI");var element=sym.$("zerglingI");var diff=element.position().left-newPos;if(diff>0){element.transition({scale:[0.5,0.5]},50);}else{element.transition({scale:[-0.5,0.5]},50);}
symbol.play("run");element.transition({x:newPos+"px"},(Math.abs(diff)+100),function(){symbol.stop("lieR");});};sym.jump=function(){sym.getSymbol("zerglingI").play("jump");};});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){console.log("executed?");});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'marine_walk_R'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",300,function(sym,e){sym.play("marine_walk_r");});
//Edge binding end
})("marine_walk_R");
//Edge symbol end:'marine_walk_R'

//=========================================================

//Edge symbol: 'zergling'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",150,function(sym,e){sym.play("run");});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",485,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1099,function(sym,e){sym.stop();});
//Edge binding end
})("zergling");
//Edge symbol end:'zergling'

//=========================================================

//Edge symbol: 'topShadow'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",992,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2000,function(sym,e){sym.stop();});
//Edge binding end
})("topShadow");
//Edge symbol end:'topShadow'
})(jQuery,AdobeEdge,"starcrafts_interaction");