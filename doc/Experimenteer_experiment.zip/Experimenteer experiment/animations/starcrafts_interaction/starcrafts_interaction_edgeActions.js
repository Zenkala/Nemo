/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      

      

      

      

      

      

      

      

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         // insert code to be run when the composition is fully loaded here
         
         //this is the function we call when the slider is moved.
         sym.positionZergling = function (newPos) {
         	console.log("new position is " + newPos);
         
         	var symbol = sym.getSymbol("zerglingI"); //Get Edge object
         
         	var element = sym.$("zerglingI"); //get jQuery object from the Symbol.
         
         	var diff = element.position().left - newPos; //Calculate how much I need to move. (where I am to the desired position)
         	if(diff>0){ //Let the Zergling look at the direction it is going by flipping the X-scale.
         		element.transition({ scale: [0.5, 0.5] }, 50);
         	} else {
         		element.transition({ scale: [-0.5, 0.5] }, 50);
         	}
         
         	symbol.play("run"); //play the run animation
         
         	//move the zergling.
         	element.transition( 
         		{ x: newPos+"px" }, //move the zergling to the desired position
         		(Math.abs(diff)+100), //do this in 100 milliseconds plus the difference. (so a longer translation takes longer to perform)
         		function(){ //when done do this given function
         			symbol.stop("lieR"); //let the zergling lie down
         		}
         	);
         };
         
         //function executed when the button is pressed
         sym.jump = function () {
         	sym.getSymbol("zerglingI").play("jump"); //play jump animation
         };

      });
      //Edge binding end

      

      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         // insert code here
         console.log("executed?");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'marine_walk_R'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 300, function(sym, e) {
         sym.play("marine_walk_r");

      });
      //Edge binding end

   })("marine_walk_R");
   //Edge symbol end:'marine_walk_R'

   //=========================================================
   
   //Edge symbol: 'zergling'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 150, function(sym, e) {
         sym.play("run");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 485, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1099, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

   })("zergling");
   //Edge symbol end:'zergling'

   //=========================================================
   
   //Edge symbol: 'topShadow'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 992, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2000, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

   })("topShadow");
   //Edge symbol end:'topShadow'

})(jQuery, AdobeEdge, "starcrafts_interaction");