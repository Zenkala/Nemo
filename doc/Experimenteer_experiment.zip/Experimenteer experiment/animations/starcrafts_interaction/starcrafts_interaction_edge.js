/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'zerglingI',
            type:'rect',
            rect:['104px','231','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'zerglingI',
            symbolName:'zergling'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["gradient", "background-image", [270,[['rgba(255,255,255,0.00)',79],['rgba(157,145,176,1.00)',100]]]],
            ["style", "width", '1024px']
         ],
         "${_something}": [
            ["style", "overflow", 'hidden']
         ],
         "${_zerglingI}": [
            ["transform", "scaleX", '0.5'],
            ["style", "top", '313px'],
            ["transform", "scaleY", '0.5'],
            ["style", "left", '284px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: false,
         timeline: [
            { id: "eid236", tween: [ "style", "${_zerglingI}", "left", '284px', { fromValue: '284px'}], position: 0, duration: 0 },
            { id: "eid231", tween: [ "style", "${_zerglingI}", "top", '313px', { fromValue: '313px'}], position: 0, duration: 0, easing: "easeOutQuad" },
            { id: "eid232", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${_zerglingI}', ['lie'] ], ""], position: 0 }         ]
      }
   }
},
"marine_walk_R": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'marine_1',
      type: 'image',
      rect: ['0px','0px','236px','264px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/marine_1.png','0px','0px']
   },
   {
      rect: ['0px','0px','236px','264px','auto','auto'],
      id: 'marine_22',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_2.png','0px','0px']
   },
   {
      rect: ['-7px','0px','236px','264px','auto','auto'],
      id: 'marine_32',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_3.png','0px','0px']
   },
   {
      rect: ['-7px','0px','236px','264px','auto','auto'],
      id: 'marine_42',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_4.png','0px','0px']
   },
   {
      rect: ['-7px','0px','236px','264px','auto','auto'],
      id: 'marine_52',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_5.png','0px','0px']
   },
   {
      rect: ['-9px','0px','236px','264px','auto','auto'],
      id: 'marine_62',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_6.png','0px','0px']
   },
   {
      rect: ['38px','10px','193px','241px','auto','auto'],
      id: 'marine_inv2',
      type: 'image',
      display: 'none',
      fill: ['rgba(0,0,0,0)','images/marine_inv.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_marine_22}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ],
         "${_marine_42}": [
            ["style", "top", '0px'],
            ["style", "left", '-7px'],
            ["style", "display", 'none']
         ],
         "${_marine_52}": [
            ["style", "top", '0px'],
            ["style", "left", '-7px'],
            ["style", "display", 'none']
         ],
         "${symbolSelector}": [
            ["style", "height", '264px'],
            ["style", "width", '236px']
         ],
         "${_marine_1}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'block']
         ],
         "${_marine_32}": [
            ["style", "top", '0px'],
            ["style", "left", '-7px'],
            ["style", "display", 'none']
         ],
         "${_marine_inv2}": [
            ["style", "top", '10px'],
            ["style", "height", '241px'],
            ["style", "display", 'none'],
            ["style", "left", '38px'],
            ["style", "width", '193px']
         ],
         "${_marine_62}": [
            ["style", "top", '0px'],
            ["style", "left", '-9px'],
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: false,
         labels: {
            "marine_walk_r": 0,
            "stand": 1000
         },
         timeline: [
            { id: "eid28", tween: [ "style", "${_marine_42}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid39", tween: [ "style", "${_marine_42}", "display", 'block', { fromValue: 'none'}], position: 150, duration: 0 },
            { id: "eid40", tween: [ "style", "${_marine_42}", "display", 'none', { fromValue: 'block'}], position: 200, duration: 0 },
            { id: "eid2", tween: [ "style", "${_marine_1}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0 },
            { id: "eid4", tween: [ "style", "${_marine_1}", "display", 'none', { fromValue: 'block'}], position: 50, duration: 0 },
            { id: "eid31", tween: [ "style", "${_marine_62}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid45", tween: [ "style", "${_marine_62}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0 },
            { id: "eid46", tween: [ "style", "${_marine_62}", "display", 'none', { fromValue: 'block'}], position: 300, duration: 0 },
            { id: "eid89", tween: [ "style", "${_marine_inv2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid88", tween: [ "style", "${_marine_inv2}", "display", 'block', { fromValue: 'none'}], position: 1000, duration: 0 },
            { id: "eid25", tween: [ "style", "${_marine_22}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid24", tween: [ "style", "${_marine_22}", "display", 'block', { fromValue: 'none'}], position: 50, duration: 0 },
            { id: "eid26", tween: [ "style", "${_marine_22}", "display", 'none', { fromValue: 'block'}], position: 100, duration: 0 },
            { id: "eid29", tween: [ "style", "${_marine_52}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid41", tween: [ "style", "${_marine_52}", "display", 'block', { fromValue: 'none'}], position: 200, duration: 0 },
            { id: "eid42", tween: [ "style", "${_marine_52}", "display", 'none', { fromValue: 'block'}], position: 250, duration: 0 },
            { id: "eid27", tween: [ "style", "${_marine_32}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid32", tween: [ "style", "${_marine_32}", "display", 'block', { fromValue: 'none'}], position: 100, duration: 0 },
            { id: "eid34", tween: [ "style", "${_marine_32}", "display", 'none', { fromValue: 'block'}], position: 150, duration: 0 }         ]
      }
   }
},
"zergling": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'zergling_1',
      type: 'image',
      rect: ['0px','0px','145px','116px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/zergling_1.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['0px','0px','145px','116px','auto','auto'],
      id: 'zergling_2',
      fill: ['rgba(0,0,0,0)','images/zergling_2.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['0px','0px','145px','116px','auto','auto'],
      id: 'zergling_3',
      fill: ['rgba(0,0,0,0)','images/zergling_3.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-4px','-7px','145px','128px','auto','auto'],
      id: 'zergling_inv2',
      fill: ['rgba(0,0,0,0)','images/zergling_inv.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-28px','184px','144px','auto','auto'],
      id: 'zerg_jump_12',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_1.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-86px','184px','144px','auto','auto'],
      id: 'zerg_jump_2',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_2.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-144px','184px','144px','auto','auto'],
      id: 'zerg_jump_3',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_3.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-185px','184px','144px','auto','auto'],
      id: 'zerg_jump_4',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_4.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-100px','184px','144px','auto','auto'],
      id: 'zerg_jump_5',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_5.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-1px','184px','144px','auto','auto'],
      id: 'zerg_jump_6',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_6.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-5px','184px','144px','auto','auto'],
      id: 'zerg_jump_7',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_7.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-5px','184px','144px','auto','auto'],
      id: 'zerg_jump_8',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_8.png','0px','0px']
   },
   {
      type: 'image',
      display: 'none',
      rect: ['-17px','-11px','184px','144px','auto','auto'],
      id: 'zerg_jump_9',
      fill: ['rgba(0,0,0,0)','images/zerg_jump_9.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_zerg_jump_2}": [
            ["style", "top", '-86px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zerg_jump_7}": [
            ["style", "top", '-5px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zergling_inv2}": [
            ["style", "top", '-7px'],
            ["style", "height", '128px'],
            ["style", "display", 'none'],
            ["style", "left", '-4px'],
            ["style", "width", '145px']
         ],
         "${_zerg_jump_12}": [
            ["style", "top", '-28px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zerg_jump_6}": [
            ["style", "top", '-1px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zergling_1}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'block']
         ],
         "${_zerg_jump_8}": [
            ["style", "top", '-5px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zerg_jump_9}": [
            ["style", "top", '-11px'],
            ["transform", "scaleX", '1'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zerg_jump_3}": [
            ["style", "top", '-144px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${symbolSelector}": [
            ["style", "height", '116px'],
            ["style", "width", '145px']
         ],
         "${_zerg_jump_5}": [
            ["style", "top", '-100px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zergling_2}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ],
         "${_zerg_jump_4}": [
            ["style", "top", '-185px'],
            ["style", "height", '144px'],
            ["style", "display", 'none'],
            ["style", "left", '-17px'],
            ["style", "width", '184px']
         ],
         "${_zergling_3}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "display", 'none']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1250,
         autoPlay: false,
         labels: {
            "run": 0,
            "stand": 250,
            "jump": 500,
            "lie": 1099,
            "lieR": 1250
         },
         timeline: [
            { id: "eid112", tween: [ "style", "${_zergling_2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInQuad" },
            { id: "eid107", tween: [ "style", "${_zergling_2}", "display", 'block', { fromValue: 'none'}], position: 50, duration: 0, easing: "easeInQuad" },
            { id: "eid108", tween: [ "style", "${_zergling_2}", "display", 'none', { fromValue: 'block'}], position: 100, duration: 0, easing: "easeInQuad" },
            { id: "eid129", tween: [ "style", "${_zerg_jump_2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid139", tween: [ "style", "${_zerg_jump_2}", "display", 'block', { fromValue: 'none'}], position: 575, duration: 0 },
            { id: "eid140", tween: [ "style", "${_zerg_jump_2}", "display", 'none', { fromValue: 'block'}], position: 650, duration: 0 },
            { id: "eid242", tween: [ "transform", "${_zerg_jump_9}", "scaleX", '-1', { fromValue: '1'}], position: 1099, duration: 151 },
            { id: "eid136", tween: [ "style", "${_zerg_jump_9}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid153", tween: [ "style", "${_zerg_jump_9}", "display", 'block', { fromValue: 'none'}], position: 1099, duration: 0 },
            { id: "eid134", tween: [ "style", "${_zerg_jump_7}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid149", tween: [ "style", "${_zerg_jump_7}", "display", 'block', { fromValue: 'none'}], position: 949, duration: 0 },
            { id: "eid150", tween: [ "style", "${_zerg_jump_7}", "display", 'none', { fromValue: 'block'}], position: 1027, duration: 0 },
            { id: "eid114", tween: [ "style", "${_zergling_inv2}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInQuad" },
            { id: "eid113", tween: [ "style", "${_zergling_inv2}", "display", 'block', { fromValue: 'none'}], position: 250, duration: 0, easing: "easeInQuad" },
            { id: "eid161", tween: [ "style", "${_zergling_inv2}", "display", 'none', { fromValue: 'block'}], position: 500, duration: 0 },
            { id: "eid105", tween: [ "style", "${_zergling_1}", "display", 'block', { fromValue: 'block'}], position: 0, duration: 0, easing: "easeInQuad" },
            { id: "eid106", tween: [ "style", "${_zergling_1}", "display", 'none', { fromValue: 'block'}], position: 50, duration: 0, easing: "easeInQuad" },
            { id: "eid132", tween: [ "style", "${_zerg_jump_5}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid145", tween: [ "style", "${_zerg_jump_5}", "display", 'block', { fromValue: 'none'}], position: 800, duration: 0 },
            { id: "eid146", tween: [ "style", "${_zerg_jump_5}", "display", 'none', { fromValue: 'block'}], position: 875, duration: 0 },
            { id: "eid128", tween: [ "style", "${_zerg_jump_12}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid137", tween: [ "style", "${_zerg_jump_12}", "display", 'block', { fromValue: 'none'}], position: 500, duration: 0 },
            { id: "eid138", tween: [ "style", "${_zerg_jump_12}", "display", 'none', { fromValue: 'block'}], position: 575, duration: 0 },
            { id: "eid135", tween: [ "style", "${_zerg_jump_8}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid151", tween: [ "style", "${_zerg_jump_8}", "display", 'block', { fromValue: 'none'}], position: 1027, duration: 0 },
            { id: "eid152", tween: [ "style", "${_zerg_jump_8}", "display", 'none', { fromValue: 'block'}], position: 1099, duration: 0 },
            { id: "eid133", tween: [ "style", "${_zerg_jump_6}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid147", tween: [ "style", "${_zerg_jump_6}", "display", 'block', { fromValue: 'none'}], position: 875, duration: 0 },
            { id: "eid148", tween: [ "style", "${_zerg_jump_6}", "display", 'none', { fromValue: 'block'}], position: 949, duration: 0 },
            { id: "eid130", tween: [ "style", "${_zerg_jump_3}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid141", tween: [ "style", "${_zerg_jump_3}", "display", 'block', { fromValue: 'none'}], position: 650, duration: 0 },
            { id: "eid142", tween: [ "style", "${_zerg_jump_3}", "display", 'none', { fromValue: 'block'}], position: 725, duration: 0 },
            { id: "eid111", tween: [ "style", "${_zergling_3}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0, easing: "easeInQuad" },
            { id: "eid109", tween: [ "style", "${_zergling_3}", "display", 'block', { fromValue: 'none'}], position: 100, duration: 0, easing: "easeInQuad" },
            { id: "eid110", tween: [ "style", "${_zergling_3}", "display", 'none', { fromValue: 'block'}], position: 150, duration: 0, easing: "easeInQuad" },
            { id: "eid131", tween: [ "style", "${_zerg_jump_4}", "display", 'none', { fromValue: 'none'}], position: 0, duration: 0 },
            { id: "eid143", tween: [ "style", "${_zerg_jump_4}", "display", 'block', { fromValue: 'none'}], position: 725, duration: 0 },
            { id: "eid144", tween: [ "style", "${_zerg_jump_4}", "display", 'none', { fromValue: 'block'}], position: 800, duration: 0 }         ]
      }
   }
},
"topShadow": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['0px','-275px','1024px','275px','auto','auto'],
      filter: [0,0,1,1,0,0,0,0,'rgba(0,0,0,0)',0,0,0],
      id: 'Rectangle2',
      stroke: [0,'rgb(0, 0, 0)','none'],
      type: 'rect',
      fill: ['rgba(212,175,241,0.00)',[270,[['rgba(159,122,216,0.43)',73],['rgba(159,122,216,0.00)',100]]]]
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '275px'],
            ["style", "width", '1024px']
         ],
         "${_Rectangle2}": [
            ["color", "background-color", 'rgba(212,175,241,0.00)'],
            ["style", "top", '-275px'],
            ["subproperty", "filter.sepia", '0'],
            ["subproperty", "filter.blur", '0px'],
            ["style", "left", '0px'],
            ["gradient", "background-image", [270,[['rgba(159,122,216,0.43)',73],['rgba(159,122,216,0.00)',100]]]]
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2000,
         autoPlay: false,
         labels: {
            "top": 0,
            "down": 1000
         },
         timeline: [
            { id: "eid202", tween: [ "style", "${_Rectangle2}", "top", '0px', { fromValue: '-275px'}], position: 0, duration: 1000, easing: "easeOutElastic" },
            { id: "eid203", tween: [ "style", "${_Rectangle2}", "top", '-275px', { fromValue: '0px'}], position: 1000, duration: 1000, easing: "easeOutExpo" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "starcrafts_interaction");
