//test.js. We do stuff external, to keep it tidy.

//this function will be called every time a new slide is called
function newSlideHdl(index, backwards){
	console.log("newSlideHdl called " + index + " backwards: " + backwards);	
	if(index==0){ //are we at the first slide?
		
	}
}

//this function will be called every time a new slide has stopped moving and is now standing in it's new position
function newSlideStopHdl(index, backwards){
	console.log("newSlideStopHdlcalled " + index + " backwards: " + backwards);
	
	if(index==0){ //are we at the first slide?
	}

}

		
//this function will be called once the module is fully realy and all libraries and assets are loaded and available
function onLoad(){	
	console.log("%c------------onLoad------------", 'background: #f0e269;');
	$(function() {
		//Add event to the slider
		$("#nm_Slider").slider('option', 'change', function(){
			//call positionZergling, as definied in the composition function, and provide the value of the slider.
			$.Edge.getComposition("starcrafts_interaction").getStage().positionZergling( $(this).slider( "value" ) );
			// $(this) refers to the element that fires this event. Much like how it worked in actionscript
		});

		//Add event to the button
		$("#nm_Button").button().click(function( event ) {
			//call the jump function, as definied in the composition.
	        $.Edge.getComposition("starcrafts_interaction").getStage().jump();
	    });
    });
}